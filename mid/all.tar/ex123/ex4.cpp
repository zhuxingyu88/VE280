#include <iostream>

using namespace std;

void ex4(){
    // Write code for exercise 4
}

int main() {
    // Write input / output here
    ex4();
    return 0;
}
