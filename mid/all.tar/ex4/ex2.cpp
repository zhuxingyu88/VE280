#include <iostream>

using namespace std;

void ex2(){
    // Write code for exercise 2
}

int main() {
    // Write input / output here
    ex2();
    return 0;
}
