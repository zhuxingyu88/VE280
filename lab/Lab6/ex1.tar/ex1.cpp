//     Subclass            Children                                        Description
//     --------            --------                                        -----------
//   ASTNode:                                                              the base class
//     ProgramNode         DeclListNode                                    the whole program
//     DeclListNode        a list of DeclNode                              a list of declarations, e.g. int a; void f(){}
//
//     DeclNode:                                                           a declaration
//       VarDeclNode       TypeNode, IdNode                                a variable declaration, e.g. int a;
//       FnDeclNode        TypeNode, IdNode, FormalsListNode, FnBodyNode   a function definition, e.g. void f(...){...}
//       FormalDeclNode    TypeNode, IdNode                                a funtion parameter declaration, e.g. int a
//
//     FormalsListNode     a list of FormalDeclNode                        a list of function parameters, e.g. (int a, bool b)
//     FnBodyNode          DeclListNode, StmtListNode                      the function body
//     StmtListNode        a list of StmtNode                              a list of statements
//
//     TypeNode:                                                           a type keyword
//       IntNode           -- none --                                      the keyword int
//       BoolNode          -- none --                                      the keyword bool
//       VoidNode          -- none --                                      the keyword void
//
//     StmtNode:                                                           a statement end with semicolon ;
//       AssignStmtNode      AssignNode                                    an assign statement, e.g. a=1;
//       PostIncStmtNode     ExpNode                                       a post increase statement, e.g. a++;
//       PostDecStmtNode     ExpNode                                       a pose decrease statement, e.g. a--;
//
//     ExpNode:                                                            an expression
//       IntLitNode          -- none --                                    an int literal, e.g. 1
//       TrueNode            -- none --                                    the keyword true
//       FalseNode           -- none --                                    the keyword false
//       IdNode              -- none --                                    an identifier, e.g. a, f, main
//       AssignNode          ExpNode, ExpNode                              an assignemnt expression, e.g. a=1 (notice no ";")

#include <iostream>
#include <string>
#include <sstream>

using namespace std;

// constants used
#define MAX_NUM_NODE 100
#define MAX_NUM_CHILD 10
#define SIZE_TAB 4

// forward declaration of classes
class ASTNode;
class ProgramNode;
class DeclListNode;
class DeclNode;
class VarDeclNode;
class FnDeclNode;
class FormalDeclNode;
class FormalsListNode;
class FnBodyNode;
class StmtListNode;
class TypeNode;
class IntNode;
class BoolNode;
class VoidNode;
class StmtNode;
class AssignStmtNode;
class PostIncStmtNode;
class PostDecStmtNode;
class ExpNode;
class IntLitNode;
class TrueNode;
class FalseNode;
class IdNode;
class AssignNode;

// **********************************************************************
// ASTNode class (base class for all other kinds of nodes)
// **********************************************************************

class ASTNode {
public:
    ASTNode(int n = 0) : num_child(n) {}
    virtual ~ASTNode(){};

    int numChild() {
        return num_child;
    }

    void setChild(int index, ASTNode* ptr) {
        children[index] = ptr;
    }

    void addIndent(int indent) {
        for (int i = 0; i < indent; ++i) {
            cout << " ";
        }
    }

    virtual void unparse(int indent) = 0;

protected:
    int num_child;
    ASTNode* children[MAX_NUM_CHILD];
};

// **********************************************************************
// ProgramNode,  DeclListNode, FormalsListNode, FnBodyNode, StmtListNode
// **********************************************************************

class ProgramNode : public ASTNode {
public:
    ProgramNode(int n = 0) : ASTNode(n) {}

    void unparse(int indent) {
        children[0]->unparse(indent);  // unparse DeclListNode
    }
};

class DeclListNode : public ASTNode {
public:
    DeclListNode(int n = 0) : ASTNode(n) {}

    void unparse(int indent) {
        for (int i = 0; i < num_child; ++i) {
            children[i]->unparse(indent);  // unparse DeclNode
        }
    }
};

class FormalsListNode : public ASTNode {
public:
    FormalsListNode(int n = 0) : ASTNode(n) {}

    void unparse(int indent) {
        // TODO
        if (num_child == 0)
            return;
        children[0]->unparse(indent);
        for (int i = 1; i < num_child; ++i) {
            cout << ", ";
            children[i]->unparse(indent);
        }
    }
};

class FnBodyNode : public ASTNode {
public:
    FnBodyNode(int n = 0) : ASTNode(n) {}

    void unparse(int indent) {
        // TODO, think about what indent value to pass to its children!
        for (int i = 0; i < num_child; ++i) {
            children[i]->unparse(indent + 4);
        }
    }
};

class StmtListNode : public ASTNode {
public:
    StmtListNode(int n = 0) : ASTNode(n) {}

    void unparse(int indent) {
        // TODO
        for (int i = 0; i < num_child; ++i) {
            children[i]->unparse(indent);
        }
    }
};

// **********************************************************************
// DeclNode and its subclasses
// **********************************************************************

class DeclNode : public ASTNode {
public:
    DeclNode(int n = 0) : ASTNode(n) {}

    virtual void unparse(int indent) = 0;
};

class VarDeclNode : public DeclNode {
public:
    VarDeclNode(int n = 0) : DeclNode(n) {}

    void unparse(int indent) {
        // TODO
        addIndent(indent);
        children[0]->unparse(indent);
        cout << " ";
        children[1]->unparse(indent);
        cout << ';' << endl;
    }
};

class FnDeclNode : public DeclNode {
public:
    FnDeclNode(int n = 0) : DeclNode(n) {}

    void unparse(int indent) {
        addIndent(indent);
        children[0]->unparse(indent);  // unparse TypeNode
        cout << " ";
        children[1]->unparse(indent);  // unparse IdNode
        cout << "(";
        children[2]->unparse(indent);  // unparse FormalsListNode
        cout << ") {" << endl;
        children[3]->unparse(indent);  // unparse FnBodyNode
        addIndent(indent);
        cout << "}" << endl;
    }
};

class FormalDeclNode : public DeclNode {
public:
    FormalDeclNode(int n = 0) : DeclNode(n) {}

    void unparse(int indent) {
        // TODO
        children[0]->unparse(indent);
        cout << " ";
        children[1]->unparse(indent);
    }
};

// **********************************************************************
// TypeNode and its Subclasses
// **********************************************************************

class TypeNode : public ASTNode {
public:
    TypeNode(int n = 0) : ASTNode(n) {}

    virtual void unparse(int indent) = 0;
};

class IntNode : public TypeNode {
public:
    IntNode(int n = 0) : TypeNode(n) {}

    void unparse(int indent) {
        // TODO
        cout << "int";
    }
};

class BoolNode : public TypeNode {
public:
    BoolNode(int n = 0) : TypeNode(n) {}

    void unparse(int indent) {
        // TODO
        cout << "bool";
    }
};

class VoidNode : public TypeNode {
public:
    VoidNode(int n = 0) : TypeNode(n) {}

    void unparse(int indent) {
        // TODO
        cout << "void";
    }
};

// **********************************************************************
// StmtNode and its subclasses
// **********************************************************************

class StmtNode : public ASTNode {
public:
    StmtNode(int n = 0) : ASTNode(n) {}

    virtual void unparse(int indent) = 0;
};

class AssignStmtNode : public StmtNode {
public:
    AssignStmtNode(int n = 0) : StmtNode(n) {}

    void unparse(int indent) {
        // TODO
        addIndent(indent);
        children[0]->unparse(indent);
        cout << ';' << endl;
    }
};

class PostIncStmtNode : public StmtNode { // addindent
public:
    PostIncStmtNode(int n = 0) : StmtNode(n) {}

    void unparse(int indent) {
        // TODO
        addIndent(indent);
        children[0]->unparse(indent);
        cout << "++;" << endl;
    }
};

class PostDecStmtNode : public StmtNode { // addindent
public:
    PostDecStmtNode(int n = 0) : StmtNode(n) {}

    void unparse(int indent) {
        // TODO
        addIndent(indent);
        children[0]->unparse(indent);
        cout << "--;" << endl;
    }
};

// **********************************************************************
// ExpNode and its subclasses
// **********************************************************************

class ExpNode : public ASTNode {
public:
    ExpNode(int n = 0) : ASTNode(n) {}

    virtual void unparse(int indent) = 0;
};

class IntLitNode : public ExpNode {
public:
    IntLitNode(int n = 0, int val = 0) {
        num_child = n;
        myVal = val;
    }

    void unparse(int indent) {
        // TODO
        cout << myVal;
    }

private:
    int myVal;
};

class TrueNode : public ExpNode {
public:
    TrueNode(int n = 0) : ExpNode(n) {}

    void unparse(int indent) {
        // TODO
        cout << "true";
    }
};

class FalseNode : public ExpNode {
public:
    FalseNode(int n = 0) : ExpNode(n) {}

    void unparse(int indent) {
        // TODO
        cout << "false";
    }
};

class IdNode : public ExpNode {
public:
    IdNode(int n = 0, string str = "") {
        num_child = n;
        myName = str;
    }

    virtual void unparse(int indent) {
        // TODO
        cout << myName;
    }

private:
    string myName;
};

class AssignNode : public ExpNode {
public:
    AssignNode(int n = 0) : ExpNode(n) {}

    void unparse(int indent) {
        // TODO
        children[0]->unparse(indent);
        cout << " = ";
        children[1]->unparse(indent);
    }
};

int main() {
    // TODO: read input line by line, allocate new node, store into array
    ASTNode* nodes[MAX_NUM_NODE];
    string line, node;
    istringstream iStream;
    getline(cin, line);
    int node_num = stoi(line);
    int child = 0;
    for (int i = 0; i < node_num; ++i) {
        getline(cin, line);
        cin.clear();
        iStream.str(line);
        iStream >> node;
        if (node == "ProgramNode")
            nodes[i] = new ProgramNode(1);
        else if (node == "DeclListNode") {
            iStream >> child;
            nodes[i] = new DeclListNode(child);
        } else if (node == "VarDeclNode")
            nodes[i] = new VarDeclNode(2);
        else if (node == "FnDeclNode")
            nodes[i] = new FnDeclNode(4);
        else if (node == "FormalDeclNode")
            nodes[i] = new FormalDeclNode(2);
        else if (node == "FormalsListNode") {
            iStream >> child;
            nodes[i] = new FormalsListNode(child);
        } else if (node == "FnBodyNode")
            nodes[i] = new FnBodyNode(2);
        else if (node == "StmtListNode") {
            iStream >> child;
            nodes[i] = new StmtListNode(child);
        } else if (node == "IntNode")
            nodes[i] = new IntNode();
        else if (node == "BoolNode")
            nodes[i] = new BoolNode();
        else if (node == "VoidNode")
            nodes[i] = new VoidNode();
        else if (node == "AssignStmtNode")
            nodes[i] = new AssignStmtNode(1);
        else if (node == "PostIncStmtNode")
            nodes[i] = new PostIncStmtNode(1);
        else if (node == "PostDecStmtNode")
            nodes[i] = new PostDecStmtNode(1);
        else if (node == "IntLitNode") {
            int val;
            iStream >> child >> val;
            nodes[i] = new IntLitNode(child, val);
        }
        else if (node == "TrueNode")
            nodes[i] = new TrueNode();
        else if (node == "FalseNode")
            nodes[i] = new FalseNode();
        else if (node == "IdNode") {
            string name;
            iStream >> child >> name;
            nodes[i] = new IdNode(child, name);
        }
        else if (node == "AssignNode")
            nodes[i] = new AssignNode(2);
        iStream.clear();
    }
    // TODO: traverse array to construct the tree
    int index = 0;
    int this_nodes_num = 1;
    int next_nodes_num = 0;
    while (index < node_num) {
        for (int i = 0; i < this_nodes_num; ++i) { // one layer
            for (int j = 0; j < nodes[index]->numChild(); ++j) { // one node
                nodes[index]->setChild(j, nodes[index + this_nodes_num - i + next_nodes_num + j]);
            }
            next_nodes_num += nodes[index]->numChild();
            ++index;
        }
        this_nodes_num = next_nodes_num;
        next_nodes_num = 0;
    }
    // call unparse() of root to print whole program
    ASTNode* root = nodes[0];
    root->unparse(0);

    // TODO: delete the allocated nodes
    for (int k = 0; k < node_num; ++k) {
        delete nodes[k];
    }
}