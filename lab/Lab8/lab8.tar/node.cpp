#include "node.h"
#include <iostream>
using namespace std;

void Node::addChild(Node *child) {
    if (child_num == n) {
        tooManyChildren error;
        throw error;
    } else {
        child->parent = this;
        children[child_num++] = child;
        Node* temp = this;
        int path_length = 1;
        while (temp){
            if (temp->height < child->height + path_length)
                temp->height = child->height + path_length;
            temp = temp->parent;
            ++path_length;
        }
    }
}

Node::Node(int _value, int _n): value(_value), child_num(0), n(_n), parent(nullptr), children(new Node*[_n]), height(0) {
}

Node::~Node() {
    for (int i = 0; i < child_num; ++i) {
        delete children[i];
    }
    delete [] children;
}

void Node::addChild(int _value) {
    if (child_num == n) {
        tooManyChildren error;
        throw error;
    } else {
        Node* temp = new Node(_value, n);
        addChild(temp);
    }
}

void Node::traverse() {
    cout << value << ' ';
    for (int i = 0; i < child_num; ++i) {
        children[i]->traverse();
    }
}

bool Node::contain(Node *sub) {
    bool contain_flag = false;
    if (this->value == sub->value) {
        contain_helper(sub, &contain_flag);
        if (contain_flag)
            return true;
    }
    for (int i = 0; i < child_num; ++i) {
        if (children[i]->contain(sub))
            return true;
    }
    return false;
}

void Node::contain_helper(Node *node1, bool *flag) {
    if (value != node1->value || child_num != node1->child_num || n != node1->n)
        *flag = false;
    else{
        if (child_num == 0 && node1->child_num == 0) {
            *flag = (value == node1->value);
            return;
        }
        for (int i = 0; i < child_num; ++i) {
            children[i]->contain_helper(node1->children[i], flag);
        }
    }

}

int Node::getHeight() {
    return height;
}

Node &Node::operator[](int i) {
    if (i < child_num && i >= 0)
        return *(children[i]);
    else {
        invalidIndex error;
        throw error;
    }
}
