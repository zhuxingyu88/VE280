//
// Created by cyx on 20-5-29.
//

#ifndef INTLIST_IMPL_H
#define INTLIST_IMPL_H

#include <iostream>
#include "mylist.h"

using namespace std;

template <class T>
void List<T>::print()
{
    node_t<T>* itr = first;
    while(itr){
        std::cout << itr->val;
        itr = itr->next;
    }
    std::cout << "\n";
}

template<class T>
void List<T>::removeAll() {
    while(!isEmpty()){
        removeFront();
    }
}

template<class T>
void List<T>::copyFrom(const List &l) {
    if (!isEmpty())
        removeAll();
    node_t<T>* itr = (node_t<T> *) l.returnHead();
    while (itr) {
        insertBack(itr->val);
        itr = itr->next;
    }
}

template<class T>
bool List<T>::isEmpty() const {
    return !first;
}

template<class T>
void List<T>::insertBack(T val) {
    node_t<T>* newnode = new node_t<T>;
    newnode->next = NULL;
    newnode->val = val;
    if (isEmpty()) {
        first = newnode;
        last = newnode;
    } else {
        last->next = newnode;
        last = newnode;
    }
}

template<class T>
T List<T>::removeFront() {
    if (isEmpty()) {
        emptyList e;
        throw e;
    }
    node_t<T>* victim = first;
    T result = victim->val;
    first = victim->next;
    delete victim;
    return result;
}

template<class T>
const node_t<T> *List<T>::returnHead() const {
    return first;
}

template<class T>
List<T>::List(): first(0), last(0) {
}

template<class T>
List<T>::List(const List &l): first(0), last(0) {
    copyFrom(l);
}

template<class T>
List<T> &List<T>::operator=(const List &l) {
    if (this != &l)
        copyFrom(l);
    return *this;
}

template<class T>
List<T>::~List() {
    removeAll();
}

int getlength(const List<int> &list) {
    int count = 0;
    node_t<int>* current = const_cast<node_t<int> *>(list.returnHead());
    while (current) {
        ++count;
        current = current->next;
    }
    return count;
}

bool isLarger(const List<int> &a, const List<int> &b) {
    if (a.isEmpty() && b.isEmpty())
        return false;
    int alength = getlength(a);
    int blength = getlength(b);
    if (alength > blength)
        return true;
    else if (alength < blength)
        return false;
    else{
        node_t<int>* anode = const_cast<node_t<int> *>(a.returnHead());
        node_t<int>* bnode = const_cast<node_t<int> *>(b.returnHead());
        for (int i = 0; i < alength; ++i) {
            for (int j = 0; j < alength - 1 - i; ++j) {
                anode = anode->next;
                bnode = bnode->next;
            }
            if (anode->val > bnode->val)
                return true;
            else if (anode->val < bnode->val)
                return false;
            else{
                anode = const_cast<node_t<int> *>(a.returnHead());
                bnode = const_cast<node_t<int> *>(b.returnHead());
            }
        }
        return false;
    }
}

List<int> Add(const List<int> &a, const List<int> &b) {
    if (a.isEmpty())
        return b;
    if (b.isEmpty())
        return a;
    List<int> list = List<int>();
    node_t<int>* anode = const_cast<node_t<int> *>(a.returnHead());
    node_t<int>* bnode = const_cast<node_t<int> *>(b.returnHead());
    int val = 0;
    int carry = 0;
    while (anode && bnode){
        val = carry + anode->val + bnode->val;
        if (val > 9){
            carry = 1;
            val -= 10;
        } else
            carry = 0;
        list.insertBack(val);
        anode = anode->next;
        bnode = bnode->next;
    }
    while (anode || bnode) {
        if (anode){
            val = carry + anode->val;
            if (val > 9){
                carry = 1;
                val -= 10;
            } else
                carry = 0;
            anode = anode->next;
        } else if (bnode) {
            val = carry + bnode->val;
            if (val > 9){
                carry = 1;
                val -= 10;
            } else
                carry = 0;
            bnode = bnode->next;
        }
        list.insertBack(val);
    }
    if (carry != 0)
        list.insertBack(carry);
    return list;
}

#endif //INTLIST_IMPL_H
