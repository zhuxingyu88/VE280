/*
 * This is an exercise of VE280 Lab 10, SU2020.
 * Written by Martin Ma.
 * Latest Update: 7/17/2020.
 * Copyright © 2020 Mars-tin. All rights reserved.
 */

#ifndef MY_STACK_IMPL_H
#define MY_STACK_IMPL_H

#include <iostream>
#include "my_stack.h"



template <class T>
void Stack<T>::print()
{
    Node<T>* itr = head;
    while(itr){
        std::cout << itr->val;
        itr = itr->next;
    }
    std::cout << "\n";
}

template<class T>
void Stack<T>::removeAll() {
    while(!isEmpty()){
        pop();
    }
}

template<class T>
void Stack<T>::copy_helper(const Node<T> *node) {
    if (!node) return; // Base case
    copy_helper(node->next);
    push(node->val);
}

template<class T>
void Stack<T>::copyFrom(const Stack &s) {
    if (!isEmpty())
        removeAll();
    copy_helper(s.head);
}

template<class T>
Stack<T>::Stack(): head(nullptr) {
}

template<class T>
Stack<T>::Stack(const Stack &s): head(nullptr) {
    copyFrom(s);
}

template<class T>
Stack<T> &Stack<T>::operator=(const Stack &s) {
    if (this != &s){
        removeAll();
        copyFrom(s);
    }
    return *this;
}

template<class T>
Stack<T>::~Stack() {
    removeAll();
}

template<class T>
bool Stack<T>::isEmpty() const {
    return !head;
}

template<class T>
size_t Stack<T>::size() const {
    size_t count = 0;
    Node<T>* current = head;
    while (current) {
        ++count;
        current = current->next;
    }
    return count;
}

template<class T>
void Stack<T>::push(T val) {
    Node<T> *np = new Node<T>;
    np->val = val;
    np->next = head;
    head = np;
}

template<class T>
void Stack<T>::pop() {
    if (isEmpty()){
        stackEmpty e;
        throw e;
    }
    Node<T> *victim = head;
    head = victim->next;
    delete victim;
}

template<class T>
T Stack<T>::top() const {
    if (isEmpty()) {
        stackEmpty e;
        throw e;
    }
    return head->val;
}

template <class T>
void reverse(Stack<T> &s) {
    if (s.isEmpty())
        return;
    T val = s.top();
    Stack<T> temp;
    while (!s.isEmpty()) {
        val = s.top();
        s.pop();
        temp.push(val);
    }
    s = temp;
}

template <class T>
Stack<T> operator +(Stack<T> &s, T val) {
    Stack<T> stack(s);
    reverse(stack);
    stack.push(val);
    reverse(stack);
    return stack;
}

template <class T>
Stack<T> operator +(Stack<T> &first, Stack<T> &second) {
    Stack<T> stack1(first), stack2(second);
    reverse(stack1);
    while (!stack1.isEmpty()) {
        T val = stack1.top();
        stack1.pop();
        stack2.push(val);
    }
    return stack2;
}

#endif //MY_STACK_IMPL_H