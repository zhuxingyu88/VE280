#include <iostream>

using namespace std;

void ex1(){
    // Write code for exercise 1
}

int main() {
    // Write input / output here
    ex1();
    return 0;
}
