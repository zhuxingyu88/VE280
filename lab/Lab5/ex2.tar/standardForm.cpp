//
// Created by Zhuoer Zhu on 10/06/2020.
//

#include <cmath>
#include "standardForm.h"

quadraticFunction::quadraticFunction(float a_in, float b_in, float c_in)
{
    a = a_in;
    b = b_in;
    c = c_in;
}
// TODO: implement this constructor


float quadraticFunction::getA() const {
    return a;
}

float quadraticFunction::getB() const {
    return b;
}

float quadraticFunction::getC() const {
    return c;
}

float quadraticFunction::evaluate(float x) {
    // TODO: implement this function
    return a * x * x + b * x + c;
}

root quadraticFunction::getRoot() {
    // TODO: implement this function
    root roots;
    complexNum root1, root2;
    float delta = b * b - 4 * a * c;
    if (delta > 0) {
        roots.realRootNum = 2;
        root1.real = (-b - sqrt(delta)) / 2 / a;
        root1.imaginary = 0;
        root2.real = (-b + sqrt(delta)) / 2 / a;
        root2.imaginary = 0;
        roots.roots[0] = root1;
        roots.roots[1] = root2;
    } else if (delta < 0) {
        roots.realRootNum = 0;
        root1.real = -b / 2 / a;
        root1.imaginary = -sqrt(-delta) / 2 / a;
        root2.real = -b / 2 / a;
        root2.imaginary = sqrt(-delta) / 2 / a;
        roots.roots[0] = root1;
        roots.roots[1] = root2;
    } else {
        roots.realRootNum = 1;
        root1.real = -b / 2 / a;
        root1.imaginary = 0;
        roots.roots[0] = root1;
        roots.roots[1] = root1;
    }
    return roots;
}

int quadraticFunction::intersect(quadraticFunction g){
    // TODO: implement this function
    if (g.getA() == a) {
        if (g.getB() == b)
            return g.getC() == c;
        else
            return true;
    } else {
        return (bool)quadraticFunction(a - g.getA(), b - g.getB(), c - g.getC()).getRoot().realRootNum;
    }
}