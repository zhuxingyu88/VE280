#include <iostream>

using namespace std;

void ex3(){
    // Write code for exercise 3
}

int main() {
    // Write input / output here
    ex3();
    return 0;
}
